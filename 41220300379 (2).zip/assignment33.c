#include <stdio.h>

int main() {
    int n, i, j;


    printf("Enter the value of n (must be odd): ");
    scanf("%d", &n);


    if (n % 2 == 0) {
        printf("Please enter an odd integer.\n");
        return 1;
    }


    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {

            if (j == i || j == n - i + 1) {
                printf("*");
            } else {

                printf("_");
            }


            if (j != n) {
                printf("_");
            }
        }

        printf("\n");
    }

    return 0;
}

