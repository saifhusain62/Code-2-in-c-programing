#include<stdio.h>
int main()

{
    int X,Y;

    printf("Enter the value of X:\n");
    scanf("%d",&X);
    printf("Enter the value of Y:\n");
    scanf("%d",&Y);
    printf("The addition is:%d\n",X+Y);
    printf("The subtraction is:%d\n",X-Y);
    printf("The Multipication is:%d\n",X*Y);

    if(Y!=0){
        printf("The Quotient is:%d",X/Y);
        printf("The Reminder is:%d",X%Y);
    }
    else{
        printf(" 0 is not count...error");
    }


}
