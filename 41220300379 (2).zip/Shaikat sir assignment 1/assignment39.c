#include <stdio.h>

int main() {
    int n, i;

    printf("Enter the value of N: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive integer for N.\n");
        return 1;
    }

    printf("Series up to %d terms: ", n);
    for (i = 1; i <= n; i++) {
        if (i < n) {
            printf("%d, ", i);
        } else {
            printf("%d\n", i);
        }
    }

    return 0;
}

