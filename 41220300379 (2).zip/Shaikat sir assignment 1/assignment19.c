#include<stdio.h>

int main()
{
    int X,Y;
    printf("Enter The first value:\n");
    scanf("%d",&X);
    printf("Enter the second value:\n");
    scanf("%d",&Y);

    X += Y;
    printf("The increment value is:%d\n",X);

    X -= Y;

    printf("The decrement value is:%d\n",X);

}
