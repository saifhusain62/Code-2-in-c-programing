#include<stdio.h>
int main()
{

    int X = 5;
    printf("%d",X);
    printf("X++:%d\n",X++);
    printf("++X:%d\n",++X);
    printf("X--:%d\n",X--);
    printf("-X:%d\n",-X);

    X = -5;
    printf("%d",X);
    printf("X++:%d\n",X++);
    printf("++X:%d\n",++X);
    printf("X--:%d\n",X--);
    printf("-X:%d\n",-X);

}
