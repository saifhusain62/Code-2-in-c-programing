#include<stdio.h>
int main()

{
    int a,b;

    scanf("%d",&a);
    scanf("%d",&b);

    printf("My age is:%d\n",a);
    printf("My age is:%d\n",b);

}
