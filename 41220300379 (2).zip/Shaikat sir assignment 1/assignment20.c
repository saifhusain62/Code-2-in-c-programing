#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter your value:\n");
    scanf("%d",&a);
    printf("Enter your 2nd value:");
    scanf("%d",&b);

    int sum1= a*b;
    int sum2 = a/b;
    printf("Multiplication:%d\n",sum1);
    printf("division:%d\n",sum2);
}
