#include <stdio.h>

int main() {
    int n, i;
    int term = 1; // Initialize the first term to 1

    printf("Enter the value of N: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive integer for N.\n");
        return 1;
    }

    printf("Series of odd numbers up to %d terms: ", n);
    for (i = 1; i <= n; i++) {
        if (i < n) {
            printf("%d, ", term);
        } else {
            printf("%d\n", term);
        }
        term += 2; // Increment to the next odd number
    }

    return 0;
}

