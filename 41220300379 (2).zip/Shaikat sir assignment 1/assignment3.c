#include<stdio.h>
int main()

{
    printf("The questions is - How to write a\n");
    printf("\comment/in C programing language?");
}
