#include<stdio.h>

#define HEIGHT 200

#define PI 3.14


int main()



{
    printf("The value of HEIGHT is:%d\n",HEIGHT);
    printf("The value of PI is:%.4f",PI);


}
