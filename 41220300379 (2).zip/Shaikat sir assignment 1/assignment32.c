#include<stdio.h>
int main()
{
    int a;
    printf("Enter your value:\n");
    scanf("%d",&a);
    if(a>0){
        printf("Yes\n");
    }
    else if(a == 0){
        printf("Zero is not a valid input\n");

    }
    else{
        printf("Negative input is not valid\n");
    }
}
