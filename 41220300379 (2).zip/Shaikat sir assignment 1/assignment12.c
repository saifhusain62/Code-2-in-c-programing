#include<stdio.h>

#define PI 3.14
#define GOLDEN_RATIO 1.62

int main()

{

    printf("The value of pi is: %.f\n",PI);
    printf("The Golden ratio value is:%.2f",GOLDEN_RATIO);
}
