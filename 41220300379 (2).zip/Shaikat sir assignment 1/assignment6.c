#include<stdio.h>
int main()

{
    int a;
    float b;
    char z;

    printf("Enter a integer value:");
    scanf("%d",&a);
    printf("Enter a floating value:");
    scanf("%f",&b);
    printf("Enter a charecter value:");
    scanf(" %c",&z);
}
