#include <stdio.h>

int main() {
    char input;

    printf("Enter a single character: ");
    scanf(" %c", &input);

    if ((input >= 'A' && input <= 'Z') || (input >= 'a' && input <= 'z')) {
        printf("%c is an Alphabet\n", input);
    } else if (input >= '0' && input <= '9') {
        printf("%c is a Digit\n", input);
    } else {
        printf("%c is a Special character\n", input);
    }

    return 0;
}
