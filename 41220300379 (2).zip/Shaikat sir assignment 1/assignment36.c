#include <stdio.h>

int main() {
    char operator;
    double number1, number2, result;

    printf("Enter the expression in the format <number1> <operator> <number2>: ");
    scanf("%lf %c %lf", &number1, &operator, &number2);

    switch (operator) {
        case '+':
            result = number1 + number2;
            printf("Addition: %.2f\n", result);
            break;
        case '-':
            result = number1 - number2;
            printf("Subtraction: %.2f\n", result);
            break;
        case '*':
            result = number1 * number2;
            printf("Multiplication: %.2f\n", result);
            break;
        case '/':
            if (number2 != 0) {
                result = number1 / number2;
                printf("Division: %.6f\n", result);
            } else {
                printf("Division: Zero as divisor is not valid!\n");
            }
            break;
        default:
            printf("Invalid operator\n");
    }

    return 0;
}
