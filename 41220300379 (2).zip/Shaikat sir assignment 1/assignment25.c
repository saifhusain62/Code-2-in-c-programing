#include<stdio.h>
#include<math.h>
int main()
{

    float x,result;

    for(x = 1;x<=180;x++){

        result = log(x) + sqrt(x);

      printf("%.2f %.6f",x,result);
    }
}

