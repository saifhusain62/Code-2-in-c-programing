#include<stdio.h>

int global = 10;
int main()

{
    int local = 20;
    printf("A.Global:%d\n",global);

    printf("B.Local:%d\n",local);

    printf("C.global:%d\n",global);



}
