#include<stdio.h>
int main()
{
   unsigned int a;
    printf("Enter a number:\n");
    scanf("%d",&a);

    if(a > 0 && (a & (a - 1)) == 0){
        printf("Yes");
    }
    else{
        printf("No");
    }
}
