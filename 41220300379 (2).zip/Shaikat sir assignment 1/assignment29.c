#include<stdio.h>
int main()

{

    int a;
    printf("Enter your main value:\n");
    scanf("%d",&a);

    if(a==0){
        printf("Zero\n",a);

        return 0;
    }
    if(a==1){
        printf("One\n");

        return 0;
    }
    if(a==2){
        printf("Two\n");

        return 0;
    }
    if(a==3){
        printf("Three\n");

        return 0;
    }
    if(a==4){
        printf("Four\n");

        return 0;
    }
    if(a==5){
        printf("Five\n");

        return 0;
    }
    if(a==6){
        printf("Six\n");

        return 0;
    }
    if(a==7){
        printf("Seven\n");

        return 0;
    }
    if(a==8){
        printf("Eight\n");

        return 0;
    }
    if(a==9){
        printf("Nine\n");

        return 0;
    }


}
