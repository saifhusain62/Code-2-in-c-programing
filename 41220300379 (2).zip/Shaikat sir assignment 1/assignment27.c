#include<stdio.h>
int main()
{
    int a,c;
    float b;

    printf("Enter your number value:\n");
    scanf("%d%f%d",&a,&b,&c);

    if(a>=0){
        printf("Positive\n");
    }
    else{
        printf("Negative\n");
    }
     if(b>=0){
        printf("Positive\n");
    }
    else{
        printf("Negative\n");
    }
     if(c>=0){
        printf("Positive\n");
    }
    else{
        printf("Negative\n");
    }

}
