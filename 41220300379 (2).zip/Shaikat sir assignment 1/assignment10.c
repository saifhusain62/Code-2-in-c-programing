#include<stdio.h>

int main()

{
    double mydouble = 3.1400000;
    int boolean = 1;
    printf("The double value is:%.6e\n",mydouble);
    printf("The boolean value is:%d",boolean);
}
