#include<stdio.h>
int main()
{

    int a,b;

    printf("Enter a value:\n");
    scanf("%d",&a);
    printf("Enter b value:\n");
    scanf("%d",&b);

    if(b>a){
        printf("The maximum value is b:%d",b);
    }
    else if(a>b){
        printf("The maximum value is a:%d\n",a);
    }
    else{
        printf("a & b is equal");
    }


}
