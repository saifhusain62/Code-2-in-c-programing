#include<stdio.h>
int main()

{
    printf("Hello world.\n");
    printf("This is my first program.C is Fun");
}
