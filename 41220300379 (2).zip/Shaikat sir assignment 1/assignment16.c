#include<stdio.h>
int main()

{

    float pi = 3.1416;


    int r;
    printf("Enter your r value:\n");
    scanf("%d",&r);

    float A = 2*pi*r;

    printf("The area is:%.2f\n",A);
}
