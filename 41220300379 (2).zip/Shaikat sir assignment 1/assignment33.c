#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter your two value:\n");
    scanf("%d%d",&a,&b);
    if(a>b){
        printf("%d is greater than %d\n",a,b);
    }
    else if(b>a){
        printf("%d is less than %d",a,b);
    }
    else{
        printf("%d is equal to %d",a,b);
    }
}
