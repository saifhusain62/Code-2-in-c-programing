#include<stdio.h>
int main()
{
  int x = 5;
  float y = 3.141593;

  char z = 'a';

  printf("The intiger value is:%d\n",x);
  printf("The floating value is:%f\n",y);
  printf(" The charecter value is:%c ",z);
}

