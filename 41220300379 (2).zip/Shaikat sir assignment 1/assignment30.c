#include<stdio.h>
int main()

{

    int a,b,c,sum;

    printf("Enter your value a:\n");
    scanf("%d",&a);
    printf("Enter your value b:\n");
    scanf("%d",&b);
    printf("Enter your value c:\n");
    scanf("%d",&c);

    sum = a+b+c;

    if(sum == 180){
        printf("Yes\n");
    }
    else{
        printf("No\n");
    }
}
