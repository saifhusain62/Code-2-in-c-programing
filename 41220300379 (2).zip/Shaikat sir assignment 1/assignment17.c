#include<stdio.h>
int main()

{
    int a;
    printf("Enter your value a :\n");
    scanf("%d",&a);

    float b;
    printf("Enter your value b:\n");
    scanf("%f",&b);

    float X=(3.31*a*a+2.01*b*b*b)/(7.16*b*b+2.01*a*a*a);
    printf("The value is:%f\n",X);
}
