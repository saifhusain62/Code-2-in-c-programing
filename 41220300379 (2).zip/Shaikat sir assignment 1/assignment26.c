#include<stdio.h>
#include<math.h>
int main()

{

    float  x,a,b,c;

    printf("Enter a floating value:\n ");
    scanf("%f",&x);

    a = ceil(x);
    b = floor(x);
    c = fabs(x);

    printf("A = %.3f",a);
    printf("B = %.3f",b);
    printf("C = %f",c);


}
