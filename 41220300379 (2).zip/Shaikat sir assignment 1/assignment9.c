#include<stdio.h>
int main()
{
    int first,middle,last;

    printf("Enter 3 integer Numbers:\n");
    scanf("%d",&first);
    scanf("%d",&middle);
    scanf("%d",&last);
    printf("First Value is:%d\n",first);
    printf("Last value is :%d\n",last);
}
