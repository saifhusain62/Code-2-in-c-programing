#include<stdio.h>
int main()
{
    int a = 100;
    float b = 1.518000;
    char c = 'z';


    printf("The integer value is:%d\n",a);
    printf("The floating value is:%f\n",b);
    printf("The charecter value is:%c\n",c);
}
