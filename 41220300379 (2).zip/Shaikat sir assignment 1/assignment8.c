#include<stdio.h>

int main()
{
    int a;
    float b;
    char x;
    scanf("%d",&a);
    scanf("%f",&b);
    while (getchar() != '\n');
    scanf("%c", &x);

    printf("The integer value is:%d\n",a);
    printf("The float value is:%f\n",b);
    printf("The charecter value is:%c", x);
}
