#include<stdio.h>
int main()

{
    int a,b,c;

    printf("Enter Your value:\n");
    scanf("%d%d%d",&a,&b,&c);

    if(a>=0){
        printf("True:1\n");
    }
    else{
        printf("False:0\n");
    }
    if(b>=0){
        printf("True:1\n");
    }
    else{
        printf("False:0\n");
    }
    if(c>=0){
        printf("True:1\n");
    }
    else{
        printf("False:0\n");
    }
}
