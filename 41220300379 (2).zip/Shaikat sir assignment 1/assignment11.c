#include<stdio.h>

int main()

{
    long int longint = 12312123;
    long long int llint = 3543153253252352;
    long double ld = 1.1E+13212;
    short int si = 12123;

    printf("The long int value:%ld\n",longint);
    printf("The long long int value is:%lld\n",llint);
    printf("The long double value is:%LE\n",ld);
    printf("Short int value is:%d\n",si);
}
